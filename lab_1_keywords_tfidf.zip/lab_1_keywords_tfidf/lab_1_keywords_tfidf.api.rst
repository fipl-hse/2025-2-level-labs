lab\_1\_keywords\_tfidf package
======================================

Submodules
----------


.. automodule:: lab_1_keywords_tfidf.main
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
   :special-members: __init__, __str__
